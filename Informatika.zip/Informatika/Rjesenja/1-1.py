# 1.1.
n = int(input())
print(0-n) # moguće je napisati print(-n)
