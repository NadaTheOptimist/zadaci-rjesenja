#3.4.
n = int(input())

print(oct(n)[2:]) # oct -> vraća niz znakova, oktalnu reprezentaciju n, u obliku 0b1234567
