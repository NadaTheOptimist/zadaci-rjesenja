#2.1.
s = input()

for i in range(len(s)):
    if i%2==0:  # i je indeks trenutnog znaka
        print(s[i])
