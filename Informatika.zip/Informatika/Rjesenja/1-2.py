#1.2.
x = input()
n = int(input())

if int(x)/n > n:
    print("DA")
else:
    print("NE")
