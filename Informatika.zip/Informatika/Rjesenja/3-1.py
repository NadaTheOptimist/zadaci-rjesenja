#3.1.b)
from funkcije import palindrom
s = input()
print(palindrom(s))
