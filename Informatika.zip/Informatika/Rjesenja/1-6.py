#1.6.
# zadatak je postavljen više kao mozgalica, jer je prvi zadatak moguće riješiti u jednoj
# liniji
print(-int(input()))
# ovo funkcionira jer se s vrijednosti int(input())-a, makar malo kontraintuitivno, može
# računati bez da se njegov return sprema u varijablu

# II - Manipulacija nizovima znakova
